import React, { Component, ErrorInfo, ReactNode } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Alert,
  Container,
  Stack
} from '@mui/material';
import { Error as ErrorIcon, Refresh } from '@mui/icons-material';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
  errorInfo?: ErrorInfo;
}

class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
    this.setState({ error, errorInfo });
  }

  handleReload = () => {
    window.location.reload();
  };

  handleReset = () => {
    this.setState({ hasError: false, error: undefined, errorInfo: undefined });
  };

  render() {
    if (this.state.hasError) {
      return (
        <Container maxWidth="md" sx={{ py: 8 }}>
          <Card sx={{ textAlign: 'center', borderRadius: 3 }}>
            <CardContent sx={{ p: 6 }}>
              <ErrorIcon sx={{ fontSize: 80, color: 'error.main', mb: 3 }} />
              
              <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold' }}>
                Oops! Bir şeyler ters gitti
              </Typography>
              
              <Typography variant="body1" color="textSecondary" sx={{ mb: 4 }}>
                Uygulama beklenmedik bir hatayla karşılaştı. Lütfen sayfayı yenileyin veya daha sonra tekrar deneyin.
              </Typography>

              {this.state.error && (
                <Alert severity="error" sx={{ mb: 4, textAlign: 'left' }}>
                  <Typography variant="subtitle2" gutterBottom>
                    Hata Detayı:
                  </Typography>
                  <Typography variant="body2" component="pre" sx={{ fontSize: '0.875rem' }}>
                    {this.state.error.message}
                  </Typography>
                </Alert>
              )}

              <Stack direction="row" spacing={2} justifyContent="center">
                <Button
                  variant="contained"
                  startIcon={<Refresh />}
                  onClick={this.handleReload}
                  className="gradient-button"
                >
                  Sayfayı Yenile
                </Button>
                <Button
                  variant="outlined"
                  onClick={this.handleReset}
                >
                  Tekrar Dene
                </Button>
              </Stack>

              <Box sx={{ mt: 4, p: 2, backgroundColor: '#f5f5f5', borderRadius: 1 }}>
                <Typography variant="body2" color="textSecondary">
                  Bu hata devam ederse, lütfen geliştirici ile iletişime geçin.
                  <br />
                  <strong>ahmetsagdasli</strong> - GitHub: @ahmetsagdasli
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Container>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;