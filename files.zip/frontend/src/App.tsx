import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { Container, Box } from '@mui/material'
import { Helmet } from 'react-helmet-async'
import { motion, AnimatePresence } from 'framer-motion'

// Layout Components
import Navbar from './components/Layout/Navbar'
import Footer from './components/Layout/Footer'

// Pages
import Dashboard from './pages/Dashboard'
import AddInvoice from './pages/AddInvoice'
import InvoiceList from './pages/InvoiceList'
import Search from './pages/Search'
import About from './pages/About'
import NotFound from './pages/NotFound'

// Context Providers
import { WalletProvider } from './context/WalletContext'
import { ContractProvider } from './context/ContractContext'

// Page transition variants
const pageVariants = {
  initial: { opacity: 0, y: 20 },
  in: { opacity: 1, y: 0 },
  out: { opacity: 0, y: -20 }
}

const pageTransition = {
  type: 'tween',
  ease: 'anticipate',
  duration: 0.4
}

function App() {
  return (
    <WalletProvider>
      <ContractProvider>
        <Box sx={{ 
          minHeight: '100vh', 
          backgroundColor: '#f5f5f5',
          display: 'flex',
          flexDirection: 'column'
        }}>
          <Helmet>
            <title>Invoice DApp - Modern Blockchain Fatura Yönetimi</title>
            <meta name="description" content="Ethereum blockchain üzerinde çalışan modern, güvenli ve kullanıcı dostu fatura yönetim sistemi. ahmetsagdasli tarafından geliştirildi." />
            <meta name="keywords" content="invoice, blockchain, ethereum, dapp, fatura, web3, smart contract" />
            <meta name="author" content="ahmetsagdasli" />
            <meta property="og:title" content="Invoice DApp - Modern Blockchain Fatura Yönetimi" />
            <meta property="og:description" content="Ethereum blockchain üzerinde çalışan modern fatura yönetim sistemi" />
            <meta property="og:type" content="website" />
            <link rel="canonical" href="/" />
          </Helmet>

          <Navbar />
          
          <Container 
            maxWidth="xl" 
            sx={{ 
              py: 3, 
              flexGrow: 1,
              display: 'flex',
              flexDirection: 'column'
            }}
          >
            <AnimatePresence mode="wait">
              <Routes>
                <Route 
                  path="/" 
                  element={
                    <motion.div
                      initial="initial"
                      animate="in"
                      exit="out"
                      variants={pageVariants}
                      transition={pageTransition}
                    >
                      <Dashboard />
                    </motion.div>
                  } 
                />
                <Route 
                  path="/add" 
                  element={
                    <motion.div
                      initial="initial"
                      animate="in"
                      exit="out"
                      variants={pageVariants}
                      transition={pageTransition}
                    >
                      <AddInvoice />
                    </motion.div>
                  } 
                />
                <Route 
                  path="/invoices" 
                  element={
                    <motion.div
                      initial="initial"
                      animate="in"
                      exit="out"
                      variants={pageVariants}
                      transition={pageTransition}
                    >
                      <InvoiceList />
                    </motion.div>
                  } 
                />
                <Route 
                  path="/search" 
                  element={
                    <motion.div
                      initial="initial"
                      animate="in"
                      exit="out"
                      variants={pageVariants}
                      transition={pageTransition}
                    >
                      <Search />
                    </motion.div>
                  } 
                />
                <Route 
                  path="/about" 
                  element={
                    <motion.div
                      initial="initial"
                      animate="in"
                      exit="out"
                      variants={pageVariants}
                      transition={pageTransition}
                    >
                      <About />
                    </motion.div>
                  } 
                />
                <Route 
                  path="/404" 
                  element={
                    <motion.div
                      initial="initial"
                      animate="in"
                      exit="out"
                      variants={pageVariants}
                      transition={pageTransition}
                    >
                      <NotFound />
                    </motion.div>
                  } 
                />
                <Route path="*" element={<Navigate to="/404" replace />} />
              </Routes>
            </AnimatePresence>
          </Container>

          <Footer />
        </Box>
      </ContractProvider>
    </WalletProvider>
  )
}

export default App