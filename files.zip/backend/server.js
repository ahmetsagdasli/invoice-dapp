/**
 * Invoice DApp Backend Server
 * Modern fatura yönetim sistemi için API
 * @author ahmetsagdasli
 */

const express = require('express');
const cors = require('cors');
const multer = require('multer');
const { create } = require('ipfs-http-client');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const compression = require('compression');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Security middleware
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
}));

// Compression middleware
app.use(compression());

// Logging middleware
app.use(morgan('combined'));

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
  message: {
    error: 'Çok fazla istek gönderildi, lütfen daha sonra tekrar deneyin.'
  }
});
app.use('/api/', limiter);

// CORS configuration
app.use(cors({
  origin: [
    'http://localhost:3000',
    'http://localhost:5173',
    'http://127.0.0.1:3000',
    'http://127.0.0.1:5173'
  ],
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  credentials: true
}));

// Body parsing middleware
app.use(express.json({ 
  limit: '50mb',
  verify: (req, res, buf) => {
    req.rawBody = buf;
  }
}));
app.use(express.urlencoded({ 
  extended: true, 
  limit: '50mb' 
}));

// IPFS client configuration
let ipfs;
try {
  ipfs = create({
    host: process.env.IPFS_HOST || 'localhost',
    port: process.env.IPFS_PORT || 5001,
    protocol: process.env.IPFS_PROTOCOL || 'http'
  });
  console.log('✅ IPFS Client initialized');
} catch (error) {
  console.error('❌ IPFS Client initialization failed:', error.message);
}

// Multer configuration
const storage = multer.memoryStorage();
const upload = multer({
  storage,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 10 * 1024 * 1024,
    files: 5
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = process.env.ALLOWED_FILE_TYPES?.split(',') || [
      'image/jpeg',
      'image/png', 
      'image/gif',
      'application/pdf'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`Desteklenmeyen dosya türü: ${file.mimetype}`), false);
    }
  }
});

// Utility functions
const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

const generateIPFSUrl = (hash) => `https://ipfs.io/ipfs/${hash}`;

// Routes

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK',
    message: '🚀 Invoice DApp Backend çalışıyor!',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    environment: process.env.NODE_ENV,
    services: {
      ipfs: !!ipfs,
      database: true, // Would be actual DB check
    }
  });
});

// API Info endpoint
app.get('/api', (req, res) => {
  res.json({
    name: 'Invoice DApp API',
    version: '1.0.0',
    description: 'Modern fatura yönetim sistemi için RESTful API',
    author: 'ahmetsagdasli',
    endpoints: {
      health: 'GET /api/health',
      upload: 'POST /api/upload',
      ipfs: 'GET /api/ipfs/:hash',
      search: 'GET /api/search'
    }
  });
});

// File upload to IPFS
app.post('/api/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ 
        success: false, 
        error: 'Dosya bulunamadı! Lütfen bir dosya seçin.' 
      });
    }

    if (!ipfs) {
      return res.status(503).json({
        success: false,
        error: 'IPFS servisi kullanılamıyor'
      });
    }

    console.log(`📁 Dosya yükleniyor: ${req.file.originalname} (${formatFileSize(req.file.size)})`);

    // Upload to IPFS
    const result = await ipfs.add({
      path: req.file.originalname,
      content: req.file.buffer
    });

    const ipfsHash = result.cid.toString();
    
    console.log(`✅ IPFS Upload Başarılı: ${ipfsHash}`);

    res.json({
      success: true,
      data: {
        ipfsHash,
        fileName: req.file.originalname,
        fileSize: req.file.size,
        fileSizeFormatted: formatFileSize(req.file.size),
        mimeType: req.file.mimetype,
        ipfsUrl: generateIPFSUrl(ipfsHash),
        uploadedAt: new Date().toISOString()
      },
      message: 'Dosya başarıyla IPFS\'e yüklendi!'
    });

  } catch (error) {
    console.error('❌ IPFS upload hatası:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Dosya yükleme hatası: ' + error.message 
    });
  }
});

// Get file from IPFS
app.get('/api/ipfs/:hash', async (req, res) => {
  try {
    const { hash } = req.params;
    
    if (!ipfs) {
      return res.status(503).json({
        success: false,
        error: 'IPFS servisi kullanılamıyor'
      });
    }

    console.log(`📥 IPFS dosya isteniyor: ${hash}`);

    const chunks = [];
    for await (const chunk of ipfs.cat(hash)) {
      chunks.push(chunk);
    }
    
    const fileBuffer = Buffer.concat(chunks);
    
    // Set headers
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="${hash}"`);
    res.setHeader('Content-Length', fileBuffer.length);
    
    res.send(fileBuffer);
    
  } catch (error) {
    console.error('❌ IPFS dosya getirme hatası:', error);
    res.status(404).json({ 
      success: false, 
      error: 'Dosya bulunamadı: ' + error.message 
    });
  }
});

// Multiple file upload
app.post('/api/upload-multiple', upload.array('files', 5), async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Hiç dosya bulunamadı!'
      });
    }

    const uploadResults = [];

    for (const file of req.files) {
      try {
        const result = await ipfs.add({
          path: file.originalname,
          content: file.buffer
        });

        uploadResults.push({
          success: true,
          fileName: file.originalname,
          ipfsHash: result.cid.toString(),
          fileSize: file.size,
          mimeType: file.mimetype
        });
      } catch (error) {
        uploadResults.push({
          success: false,
          fileName: file.originalname,
          error: error.message
        });
      }
    }

    res.json({
      success: true,
      message: `${uploadResults.filter(r => r.success).length}/${req.files.length} dosya başarıyla yüklendi`,
      results: uploadResults
    });

  } catch (error) {
    console.error('❌ Multiple upload hatası:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Search endpoint (placeholder)
app.get('/api/search', (req, res) => {
  try {
    const { q, category, dateFrom, dateTo, limit = 50 } = req.query;
    
    console.log('🔍 Arama parametreleri:', { q, category, dateFrom, dateTo, limit });
    
    // Bu normalde veritabanından gelir
    res.json({
      success: true,
      data: {
        results: [],
        totalCount: 0,
        query: q,
        filters: { category, dateFrom, dateTo },
        limit: parseInt(limit)
      },
      message: 'Arama tamamlandı'
    });
    
  } catch (error) {
    console.error('❌ Arama hatası:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Arama hatası: ' + error.message 
    });
  }
});

// Stats endpoint
app.get('/api/stats', (req, res) => {
  res.json({
    success: true,
    data: {
      totalInvoices: 0,
      totalAmount: 0,
      uniqueCompanies: 0,
      recentInvoices: 0,
      lastUpdated: new Date().toISOString()
    }
  });
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('❌ Server hatası:', error);
  
  if (error instanceof multer.MulterError) {
    if (error.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        success: false,
        error: `Dosya boyutu çok büyük! Maksimum ${formatFileSize(parseInt(process.env.MAX_FILE_SIZE) || 10485760)}`
      });
    }
    if (error.code === 'LIMIT_FILE_COUNT') {
      return res.status(400).json({
        success: false,
        error: 'Çok fazla dosya! Maksimum 5 dosya yükleyebilirsiniz.'
      });
    }
  }
  
  res.status(500).json({
    success: false,
    error: process.env.NODE_ENV === 'development' ? error.message : 'Sunucu hatası oluştu'
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    error: 'Endpoint bulunamadı!',
    requestedUrl: req.originalUrl,
    availableEndpoints: [
      'GET /api/health',
      'GET /api',
      'POST /api/upload',
      'GET /api/ipfs/:hash',
      'GET /api/search'
    ]
  });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('👋 SIGTERM received, shutting down gracefully');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('👋 SIGINT received, shutting down gracefully');
  process.exit(0);
});

// Start server
app.listen(PORT, () => {
  console.log('\n🚀 Invoice DApp Backend Started!');
  console.log('═══════════════════════════════════');
  console.log(`📡 Server: http://localhost:${PORT}`);
  console.log(`🏥 Health: http://localhost:${PORT}/api/health`);
  console.log(`📁 Upload: http://localhost:${PORT}/api/upload`);
  console.log(`🔍 Search: http://localhost:${PORT}/api/search`);
  console.log(`🌐 Environment: ${process.env.NODE_ENV}`);
  console.log(`💾 IPFS: ${process.env.IPFS_HOST}:${process.env.IPFS_PORT}`);
  console.log('═══════════════════════════════════\n');
});

module.exports = app;